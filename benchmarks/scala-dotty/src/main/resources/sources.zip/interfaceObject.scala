trait A{
  object O
}
class B extends A {
  def foo = O
}
